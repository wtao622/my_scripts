## Version: v4.0.1
## Date: 2021-03-25
## Update Content: 增加jcode脚本用到的HelpType的一个可选值：填“2”使用“随机顺序助力模板”，本套脚本内账号间随机顺序助力，每次生成的顺序都不一致。

## ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 第一区域：jd_scripts特有变量填写区域（需要shell转换的） ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓

## Cookie（必填，由脚本去export JD_COOKIE，无需在config.sh中export）
## 请依次填入每个用户的Cookie，Cookie的具体形式（只有pt_key字段和pt_pin字段，没有其他字段）：pt_key=xxxxxxxxxx;pt_pin=xxxx;
## 1. 如果是通过控制面板编辑本文件，点击页面上方“扫码获取Cookie”即可获取，此方式获取的Cookie有效期为3个月
## 2. 还可以通过浏览器开发工具获取，此方式获得的Cookie只有1个月有效期
## 必须按数字顺序1、2、3、4...依次编号下去，例子只有6个，超出6个你继续往下编号即可
## 不允许有汉字，如果ID有汉字，请在PC浏览器上获取Cookie，会自动将汉字转换为URL编码


Cookie1=""


Cookie2=""


Cookie3=""

Cookie4=""

Cookie5=""


Cookie6=""

Cookie7=""



## 每日签到的通知形式（选填，JD_BEAN_SIGN_STOP_NOTIFY和JD_BEAN_SIGN_NOTIFY_SIMPLE，由脚本去export，无需在config.sh中export）
## js脚本每日签到提供3种通知方式，分别为：关闭通知，请填入0；简洁通知，请填入1；长通知，请填入2
NotifyBeanSign="1"

## UN_SUBSCRIBES（选填，由脚本去export，无需在config.sh中export）
goodPageSize="50"   ## 商品取关数量
shopPageSize="50"   ## 店铺取关数量
jdUnsubscribeStopGoods=""  ## 遇到此商品不再取关此商品以及它后面的商品，需去商品详情页长按拷贝商品信息
jdUnsubscribeStopShop=""   ## 遇到此店铺不再取关此店铺以及它后面的店铺，请从头开始输入店铺名称

## ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑ 第一区域：jd_scripts脚本特有变量填写区域（需要shell转换的） ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑



## ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 第二区域：jd_scripts特有变量填写区域（不需要shell转换的） ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
## 请在本区域补充其他你需要用到变量，export 变量名="变量值"，或：export 变量名='变量值'
## 其他变量详见：https://gitee.com/lxk0301/jd_docker/blob/master/githubAction.md
## 该链接中除JD_COOKIE、JD_BEAN_SIGN_STOP_NOTIFY、JD_BEAN_SIGN_NOTIFY_SIMPLE、UN_SUBSCRIBES这四个变量以及所有互助码类变量外，其他所有变量请在本区域自行补充


## ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑ 第二区域：jd_scripts脚本特有变量填写区域（不需要shell转换的） ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑



## ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 第三区域：互助码填写区域 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓

## 互助码填法示例
## **互助码是填在My系列变量中的，ForOther系统变量中只要填入My系列的变量名即可，按注释中的例子拼接，以jd_fruit为例，如下所示。**
## **实际上jd_fruit一个账号只能给别人助力3次，我多写的话，只有前几个会被助力。但如果前面的账号获得的助力次数已经达到上限了，那么还是会尝试继续给余下的账号助力，所以多填也是有意义的。**
## **ForOther系列变量必须从1开始编号，依次编下去。**

# MyFruit1="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"  # 这是Cookie1这个账号的互助码
# MyFruit2="bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"  # 这是Cookie2这个账号的互助码
# MyFruit3="cccccccccccccccccccccccccccccccc"  # 这是Cookie3这个账号的互助码
# MyFruit4="dddddddddddddddddddddddddddddddd"  # 这是Cookie4这个账号的互助码
# MyFruit5="eeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"  # 这是Cookie5这个账号的互助码
# MyFruit6="ffffffffffffffffffffffffffffffff"  # 这是Cookie6这个账号的互助码
# MyFruitA="gggggggggggggggggggggggggggggggg"  # 这是我和别人交换互助，另外一个用户A的互助码
# MyFruitB="hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh"  # 这是我和别人交换互助，另外一个用户B的互助码
# MyFruitC="iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii"  # 这是我和别人交换互助，另外一个用户C的互助码

# ForOtherFruit1="${MyFruit2}@${MyFruitB}@${MyFruit4}"   # Cookie1这个账号助力Cookie2的账号的账号、Cookie4的账号以及用户B
# ForOtherFruit2="${MyFruit1}@${MyFruitA}@${MyFruit4}"   # Cookie2这个账号助力Cookie1的账号的账号、Cookie4的账号以及用户A
# ForOtherFruit3="${MyFruit1}@${MyFruit2}@${MyFruitC}@${MyFruit4}@${MyFruitA}@${MyFruit6}"  # 解释同上，jd_fruit实际上只能助力3次
# ForOtherFruit4="${MyFruit1}@${MyFruit2}@${MyFruit3}@${MyFruitC}@${MyFruit6}@${MyFruitA}"  # 解释同上，jd_fruit实际上只能助力3次
# ForOtherFruit5="${MyFruit1}@${MyFruit2}@${MyFruit3}@${MyFruitB}@${MyFruit4}@${MyFruit6}@${MyFruitC}@${MyFruitA}"
# ForOtherFruit6="${MyFruit1}@${MyFruit2}@${MyFruit3}@${MyFruitA}@${MyFruit4}@${MyFruit5}@${MyFruitC}"


## jd_fruit互助（选填）
MyFruit1=""
MyFruit2=""
MyFruit3=""
MyFruit4=""
MyFruit5=""
MyFruit6=""
MyFruitA="26c6b461fba74eae8764b99a7ccabc81"
MyFruitB="13c59d475d634464a3956d8a117ec05e"
MyFruitC="8864669b037649d2b681d43a664c7348"

ForOtherFruit1="${MyFruitB}@${MyFruitC}"
ForOtherFruit2="${MyFruitA}@${MyFruitB}@${MyFruitC}"
ForOtherFruit3="${MyFruitA}@${MyFruitB}@${MyFruitC}"
ForOtherFruit4="${MyFruitA}@${MyFruitB}@${MyFruitC}"
ForOtherFruit5="${MyFruitA}@${MyFruitB}@${MyFruitC}"
ForOtherFruit6="${MyFruitA}@${MyFruitB}@${MyFruitC}"
ForOtherFruit7="${MyFruitA}@${MyFruitB}@${MyFruitC}"
ForOtherFruit8="${MyFruitA}@${MyFruitB}@${MyFruitC}"
ForOtherFruit9="${MyFruitA}@${MyFruitB}@${MyFruitC}"
ForOtherFruit10="${MyFruitA}@${MyFruitB}@${MyFruitC}"
ForOtherFruit11="${MyFruitA}@${MyFruitB}@${MyFruitC}"
ForOtherFruit12="${MyFruitA}@${MyFruitB}@${MyFruitC}"



################################## 定义jd_pet互助（选填） ##################################
## 具体填法及要求详见本文件最下方“互助码填法示例”
MyPet1=""
MyPet2=""
MyPet3=""
MyPet4=""
MyPet5=""
MyPet6=""
MyPetA="MTAxODc2NTEzMDAwMDAwMDAyMDY2ODczNQ=="
MyPetB="MTAxODc2NTEzMDAwMDAwMDAyMDY2ODczNQ=="
MyPetC="MTAxODc2NTEzMjAwMDAwMDAyMDQzOTc4Nw=="

ForOtherPet1="${MyPetB}@${MyPetC}"
ForOtherPet2="${MyPetA}@${MyPetB}@${MyPetC}"
ForOtherPet3="${MyPetA}@${MyPetB}@${MyPetC}"
ForOtherPet4="${MyPetA}@${MyPetB}@${MyPetC}"
ForOtherPet5="${MyPetA}@${MyPetB}@${MyPetC}"
ForOtherPet6="${MyPetA}@${MyPetB}@${MyPetC}"
ForOtherPet7="${MyPetA}@${MyPetB}@${MyPetC}"
ForOtherPet8="${MyPetA}@${MyPetB}@${MyPetC}"
ForOtherPet9="${MyPetA}@${MyPetB}@${MyPetC}"
ForOtherPet10="${MyPetA}@${MyPetB}@${MyPetC}"
ForOtherPet11="${MyPetA}@${MyPetB}@${MyPetC}"
ForOtherPet12="${MyPetA}@${MyPetB}@${MyPetC}"


################################## 定义jd_plantBean互助（选填） ##################################
## 具体填法及要求详见本文件最下方“互助码填法示例”
MyBean1=""
MyBean2=""
MyBean3=""
MyBean4=""
MyBean5=""
MyBean6=""
MyBeanA="olmijoxgmjutyjqjygcacges7ijukkf4wuebt6i"
MyBeanB="xmblfgd3rmwo5za7i4mfalb6pfmn7nshle5syba"
MyBeanC="olmijoxgmjutykfpopwwt54pok4fu3s2rfxq44q"

ForOtherBean1="${MyBeanB}@${MyBeanC}"
ForOtherBean2="${MyBeanA}@${MyBeanB}@${MyBeanC}"
ForOtherBean3="${MyBeanA}@${MyBeanB}@${MyBeanC}"
ForOtherBean4="${MyBeanA}@${MyBeanB}@${MyBeanC}"
ForOtherBean5="${MyBeanA}@${MyBeanB}@${MyBeanC}"
ForOtherBean6="${MyBeanA}@${MyBeanB}@${MyBeanC}"
ForOtherBean7="${MyBeanA}@${MyBeanB}@${MyBeanC}"
ForOtherBean8="${MyBeanA}@${MyBeanB}@${MyBeanC}"
ForOtherBean9="${MyBeanA}@${MyBeanB}@${MyBeanC}"
ForOtherBean10="${MyBeanA}@${MyBeanB}@${MyBeanC}"


################################## 定义jd_dreamFactory互助（选填） ##################################
## 具体填法及要求详见本文件最下方“互助码填法示例”
MyDreamFactory1=""
MyDreamFactory2=""
MyDreamFactory3=""
MyDreamFactory4=""
MyDreamFactory5=""
MyDreamFactory6=""
MyDreamFactoryA="yY4MhWFhGZ0eUp7F1UubKA=="
MyDreamFactoryB="mQLNNeaiG5swOrUhRJ31bA=="
MyDreamFactoryC="fe96fpZb7hx8dRLixh2UEQ=="

ForOtherDreamFactory1="${MyDreamFactoryB}@${MyDreamFactoryC}"
ForOtherDreamFactory2="${MyDreamFactoryA}@${MyDreamFactoryB}@${MyDreamFactoryC}"
ForOtherDreamFactory3="${MyDreamFactoryA}@${MyDreamFactoryB}@${MyDreamFactoryC}"
ForOtherDreamFactory4="${MyDreamFactoryA}@${MyDreamFactoryB}@${MyDreamFactoryC}"
ForOtherDreamFactory5="${MyDreamFactoryA}@${MyDreamFactoryB}@${MyDreamFactoryC}"
ForOtherDreamFactory6="${MyDreamFactoryA}@${MyDreamFactoryB}@${MyDreamFactoryC}"
ForOtherDreamFactory7="${MyDreamFactoryA}@${MyDreamFactoryB}@${MyDreamFactoryC}"
ForOtherDreamFactory8="${MyDreamFactoryA}@${MyDreamFactoryB}@${MyDreamFactoryC}"
ForOtherDreamFactory9="${MyDreamFactoryA}@${MyDreamFactoryB}@${MyDreamFactoryC}"
ForOtherDreamFactory10="${MyDreamFactoryA}@${MyDreamFactoryB}@${MyDreamFactoryC}"


################################## 定义jd_jdfactory互助（选填） ##################################
## 具体填法及要求详见本文件最下方“互助码填法示例”
MyJdFactory1=""
MyJdFactory2=""
MyJdFactory3=""
MyJdFactory4=""
MyJdFactory5=""
MyJdFactory6=""
MyJdFactoryA="P04z54XCjVWnYaS5m9cZ2b8j3lLlJH094OnC9I"
MyJdFactoryB="P04z54XCjVWnYaS5m9cZzKkpycg9OettKcmdw"
MyJdFactoryC="T0225KkcRhxK_FHUdB7zkv9eJgCjVWnYaS5kRrbA"

ForOtherJdFactory1="${MyJdFactoryB}@${MyJdFactoryC}"
ForOtherJdFactory2="${MyJdFactoryA}@${MyJdFactoryB}@${MyJdFactoryC}"
ForOtherJdFactory3="${MyJdFactoryA}@${MyJdFactoryB}@${MyJdFactoryC}"
ForOtherJdFactory4="${MyJdFactoryA}@${MyJdFactoryB}@${MyJdFactoryC}"
ForOtherJdFactory5="${MyJdFactoryA}@${MyJdFactoryB}@${MyJdFactoryC}"
ForOtherJdFactory6="${MyJdFactoryA}@${MyJdFactoryB}@${MyJdFactoryC}"
ForOtherJdFactory7="${MyJdFactoryA}@${MyJdFactoryB}@${MyJdFactoryC}"
ForOtherJdFactory8="${MyJdFactoryA}@${MyJdFactoryB}@${MyJdFactoryC}"
ForOtherJdFactory9="${MyJdFactoryA}@${MyJdFactoryB}@${MyJdFactoryC}"
ForOtherJdFactory10="${MyJdFactoryA}@${MyJdFactoryB}@${MyJdFactoryC}"


################################## 定义jd_jdzz互助（选填） ##################################
## 具体填法及要求详见本文件最下方“互助码填法示例”
MyJdzz1=""
MyJdzz2=""
MyJdzz3=""
MyJdzz4=""
MyJdzz5=""
MyJdzz6=""
MyJdzzA="S5KkcRhpL8FXWcxrzxqZYcA"
MyJdzzB="S5KkcEkJjrj62Xk2R6IFN"
MyJdzzC="S5KkcRhxK_FHUdB7zkv9eJg"

ForOtherJdzz1="${MyJdzzA}@${MyJdzzC}"
ForOtherJdzz2="${MyJdzzA}@${MyJdzzB}@${MyJdzzC}"
ForOtherJdzz3="${MyJdzzA}@${MyJdzzB}@${MyJdzzC}"
ForOtherJdzz4="${MyJdzzA}@${MyJdzzB}@${MyJdzzC}"
ForOtherJdzz5="${MyJdzzA}@${MyJdzzB}@${MyJdzzC}"
ForOtherJdzz6="${MyJdzzA}@${MyJdzzB}@${MyJdzzC}"
ForOtherJdzz7="${MyJdzzA}@${MyJdzzB}@${MyJdzzC}"
ForOtherJdzz8="${MyJdzzA}@${MyJdzzB}@${MyJdzzC}"
ForOtherJdzz9="${MyJdzzA}@${MyJdzzB}@${MyJdzzC}"
ForOtherJdzz10="${MyJdzzA}@${MyJdzzB}@${MyJdzzC}"


################################## 定义jd_crazy_joy互助（选填） ##################################
## 具体填法及要求详见本文件最下方“互助码填法示例”
MyJoy1=""
MyJoy2=""
MyJoy3=""
MyJoy4=""
MyJoy5=""
MyJoy6=""
MyJoyA="eo5lf9mPzsGLoqgTlmN-AKt9zd5YaBeE"
MyJoyB="sEaeCDtGdUB_VFRCJhMp7A=="
MyJoyC="JDajqIExihJ_1fAyY7YRsKt9zd5YaBeE"

ForOtherJoy1="${MyJoyB}@${MyJoyC}"
ForOtherJoy2="${MyJoyA}@${MyJoyB}@${MyJoyC}"
ForOtherJoy3="${MyJoyA}@${MyJoyB}@${MyJoyC}"
ForOtherJoy4="${MyJoyA}@${MyJoyB}@${MyJoyC}"
ForOtherJoy5="${MyJoyA}@${MyJoyB}@${MyJoyC}"
ForOtherJoy6="${MyJoyA}@${MyJoyB}@${MyJoyC}"
ForOtherJoy7="${MyJoyA}@${MyJoyB}@${MyJoyC}"
ForOtherJoy8="${MyJoyA}@${MyJoyB}@${MyJoyC}"
ForOtherJoy9="${MyJoyA}@${MyJoyB}@${MyJoyC}"
ForOtherJoy10="${MyJoyA}@${MyJoyB}@${MyJoyC}"

################################## 定义jd_jxnc互助（选填） ##################################
## 具体填法及要求详见本文件最下方“互助码填法示例”
## jd_jxnc助力码为 JSON 格式因此使用单引号，json 格式如下
## {"smp":"22bdadsfaadsfadse8a","active":"jdnc_1_btorange210113_2","joinnum":"1"}
## 助力码获取可以通过 bash jd.sh jd_get_share_code now 命令获取
## 注意：jd_jxnc 种植种子发生变化的时候，互助码也会变！！
MyJxnc1=""
MyJxnc2=""
MyJxnc3=""
MyJxnc4=""
MyJxnc5=""
MyJxnc6=""
MyJxncA="{"smp":"1b559d440f856408d7787940c68996b3","active":"jdnc_1_caomi210305_2","joinnum":1}"
MyJxncB="{"smp":"0a83f30ec0562e33e428eefd0b50b98e","active":"jdnc_1_sxhuasheng210305_2","joinnum":1}"
MyJxncC="{"smp":"b5ad62bef35cdaedafa857c231915a17","active":"jdnc_1_xuelianguo210126_2","joinnum":1}"

ForOtherJxnc1="${MyJxncB}@${MyJxncC}"
ForOtherJxnc2="${MyJxncA}@${MyJxncB}@${MyJxncC}"
ForOtherJxnc3="${MyJxncA}@${MyJxncB}@${MyJxncC}"
ForOtherJxnc4="${MyJxncA}@${MyJxncB}@${MyJxncC}"
ForOtherJxnc5="${MyJxncA}@${MyJxncB}@${MyJxncC}"
ForOtherJxnc6="${MyJxncA}@${MyJxncB}@${MyJxncC}"
ForOtherJxnc7="${MyJxncA}@${MyJxncB}@${MyJxncC}"
ForOtherJxnc8="${MyJxncA}@${MyJxncB}@${MyJxncC}"
ForOtherJxnc9="${MyJxncA}@${MyJxncB}@${MyJxncC}"
ForOtherJxnc10="${MyJxncA}@${MyJxncB}@${MyJxncC}"


################################## 定义jd_bookshop互助（选填） ##################################
## 具体填法及要求详见本文件最下方“互助码填法示例”
MyBookShop1=""
MyBookShop2=""
MyBookShop3=""
MyBookShop4=""
MyBookShop5=""
MyBookShop6=""
MyBookShopA="786362b4b1cf4ad69e31b767d511637c"
MyBookShopB="531916ed70654ea3ac9dbc6df81e436a"

ForOtherBookShop1="${MyBookShopB}"
ForOtherBookShop2="${MyBookShopA}@${MyBookShopB}"
ForOtherBookShop3="${MyBookShopA}@${MyBookShopB}"
ForOtherBookShop4="${MyBookShopA}@${MyBookShopB}"
ForOtherBookShop5="${MyBookShopA}@${MyBookShopB}"
ForOtherBookShop6="${MyBookShopA}@${MyBookShopB}"
ForOtherBookShop7="${MyBookShopA}@${MyBookShopB}"
ForOtherBookShop8="${MyBookShopA}@${MyBookShopB}"
ForOtherBookShop9="${MyBookShopA}@${MyBookShopB}"
ForOtherBookShop10="${MyBookShopA}@${MyBookShopB}"


################################## 定义jd_cash互助（选填） ##################################
## 具体填法及要求详见本文件最下方“互助码填法示例”
MyCash1=""
MyCash2="eU9YaurmN_Qi9GjdnSAVgA"
MyCash3=""
MyCash4=""
MyCash5=""
MyCash6=""
MyCashA="eU9YaujgY_0nom7SmSJB0g"
MyCashB="eU9YPrDIPZZHjzmwtwVU"
MyCashC="eU9Yau7hb_klpWrSzXtHhA"

ForOtherCash1="${MyCashB}@${MyCashC}@${MyCash2}"
ForOtherCash2="${MyCashA}@${MyCashB}@${MyCashC}@${MyCash2}"
ForOtherCash3="${MyCashA}@${MyCashB}@${MyCashC}@${MyCash2}"
ForOtherCash4="${MyCashA}@${MyCashB}@${MyCashC}@${MyCash2}"
ForOtherCash5="${MyCashA}@${MyCashB}@${MyCashC}@${MyCash2}"
ForOtherCash6="${MyCashA}@${MyCashB}@${MyCashC}@${MyCash2}"
ForOtherCash7="${MyCashA}@${MyCashB}@${MyCashC}@${MyCash2}"
ForOtherCash8="${MyCashA}@${MyCashB}@${MyCashC}@${MyCash2}"
ForOtherCash9="${MyCashA}@${MyCashB}@${MyCashC}@${MyCash2}"
ForOtherCash10="${MyCashA}@${MyCashB}@${MyCashC}@${MyCash2}"


################################## 定义jd_sgmh互助（选填） ##################################
## 具体填法及要求详见本文件最下方“互助码填法示例”
MySgmh1=""
MySgmh2=""
MySgmh3=""
MySgmh4=""
MySgmh5=""
MySgmh6=""
MySgmhA="T0205KkcEkJjrj62Xk2R6IFNCjVQmoaT5kRrbA"
MySgmhB="T012-qQgBE9KIdxRCjVQmoaT5kRrbA"
MySgmhC="T0225KkcRhxK_FHUdB7zkv9eJgCjVQmoaT5kRrbA"

ForOtherSgmh1="${MySgmhA}@${MySgmhB}@${MySgmhC}"
ForOtherSgmh2="${MySgmhA}@${MySgmhB}@${MySgmhC}"
ForOtherSgmh3="${MySgmhA}@${MySgmhB}@${MySgmhC}"
ForOtherSgmh4="${MySgmhA}@${MySgmhB}@${MySgmhC}"
ForOtherSgmh5="${MySgmhA}@${MySgmhB}@${MySgmhC}"
ForOtherSgmh6="${MySgmhA}@${MySgmhB}@${MySgmhC}"
ForOtherSgmh7="${MySgmhA}@${MySgmhB}@${MySgmhC}"
ForOtherSgmh8="${MySgmhA}@${MySgmhB}@${MySgmhC}"
ForOtherSgmh9="${MySgmhA}@${MySgmhB}@${MySgmhC}"
ForOtherSgmh10="${MySgmhA}@${MySgmhB}@${MySgmhC}"
ForOtherSgmh11="${MySgmhA}@${MySgmhB}@${MySgmhC}"
ForOtherSgmh12="${MySgmhA}@${MySgmhB}@${MySgmhC}"


################################## 定义jd_cfd活动互助（选填） ##################################
## 具体填法及要求详见本文件最下方“互助码填法示例”
MyCfd1=""
MyCfd2=""
MyCfd3=""
MyCfd4=""
MyCfd5=""
MyCfd6=""
MyCfdA="9F9592AA9EA22D2D2F83DE0D0FD748C4C4E9800676B8CFD34FB09ABD5B424FE4"
MyCfdB="94180BA0783DCC197307D2832976E6CEA08C0B5266D76B0BDC2031596022AAD9"
MyCfdC="46FBABC03B147B530196D4BA30850C5ADB9E7491CA6DEC11A824F4FD613E5094"

ForOtherCfd1="${MyCfdA}@${MyCfdB}@${MyCfdC}"
ForOtherCfd2="${MyCfdA}@${MyCfdB}@${MyCfdC}"
ForOtherCfd3="${MyCfdA}@${MyCfdB}@${MyCfdC}"
ForOtherCfd4="${MyCfdA}@${MyCfdB}@${MyCfdC}"
ForOtherCfd5="${MyCfdA}@${MyCfdB}@${MyCfdC}"
ForOtherCfd6="${MyCfdA}@${MyCfdB}@${MyCfdC}"
ForOtherCfd7="${MyCfdA}@${MyCfdB}@${MyCfdC}"
ForOtherCfd8="${MyCfdA}@${MyCfdB}@${MyCfdC}"
ForOtherCfd9="${MyCfdA}@${MyCfdB}@${MyCfdC}"
ForOtherCfd10="${MyCfdA}@${MyCfdB}@${MyCfdC}"
ForOtherCfd11="${MyCfdA}@${MyCfdB}@${MyCfdC}"
ForOtherCfd12="${MyCfdA}@${MyCfdB}@${MyCfdC}"


################################## 定义jd_global活动互助（选填） ##################################
## 具体填法及要求详见本文件最下方“互助码填法示例”
MyGlobal1=""
MyGlobal2=""
MyGlobal3=""
MyGlobal4=""
MyGlobal5=""
MyGlobal6=""
MyGlobalA=""
MyGlobalB="MzIyYXpNVTJ1aDQ3Z09sb2xDWjh3dz09"
MyGlobalC="RmxaR3JNS2ZqK2RwZDEybTVHOXl5MGVWb0VXY0ZzaEptaGdpUHlad0hFTT0="

ForOtherGlobal1="${MyGlobalB}@${MyGlobalC}"
ForOtherGlobal2="${MyGlobalB}@${MyGlobalC}"
ForOtherGlobal3="${MyGlobalB}@${MyGlobalC}"
ForOtherGlobal4="${MyGlobalB}@${MyGlobalC}"
ForOtherGlobal5="${MyGlobalB}@${MyGlobalC}"
ForOtherGlobal6="${MyGlobalB}@${MyGlobalC}"
ForOtherGlobal7="${MyGlobalB}@${MyGlobalC}"
ForOtherGlobal8="${MyGlobalB}@${MyGlobalC}"
ForOtherGlobal9="${MyGlobalB}@${MyGlobalC}"
ForOtherGlobal10="${MyGlobalB}@${MyGlobalC}"
ForOtherGlobal11="${MyGlobalB}@${MyGlobalC}"
ForOtherGlobal12="${MyGlobalB}@${MyGlobalC}"



## jd_city活动互助（选填）
MyCity1=''
MyCity2=''
MyCityA=''
MyCityB=''

ForOtherCity1=""
ForOtherCity2=""

## ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑ 第三区域：互助码填写区域 ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

################################## 定义jd_superMarket蓝币兑换数量（选填） ##################################
## jd_superMarket蓝币兑换，可用值包括：
## 一、0：表示不兑换京豆，这也是js脚本的默认值
## 二、20：表示兑换20个京豆
## 三、1000：表示兑换1000个京豆
## 四、可兑换清单的商品名称，输入能跟唯一识别出来的关键词即可，比如：MARKET_COIN_TO_BEANS="抽纸"
## 注意：有些比较贵的实物商品JD只是展示出来忽悠人的，即使你零点用脚本去抢，也会提示没有或提示已下架
MARKET_COIN_TO_BEANS="20"


################################## 定义jd_superMarket蓝币成功兑换奖品是否静默运行（选填） ##################################
## 默认 "false" 关闭（即:奖品兑换成功后会发出通知提示），如需要静默运行不发出通知，请改为 "true"
MARKET_REWARD_NOTIFY=""


################################## 定义jd_superMarket是否自动使用金币去抽奖（选填） ##################################
## 是否用金币去抽奖，默认 "false" 关闭，如需开启，请修改为 "true"
SUPERMARKET_LOTTERY=""


################################## 定义jd_superMarket是否自动参加PK队伍（选填） ##################################
## 是否每次PK活动参加脚本作者创建的PK队伍，"true" 表示参加，"false" 表示不参加，默认为 "true"
JOIN_PK_TEAM=""


################################## 定义jd_fruit是否静默运行（选填） ##################################
## 默认为 "false"，不静默，发送推送通知消息，如不想收到通知，请修改为 "true"
## 如果你不想完全关闭或者完全开启通知，只想在特定的时间发送通知，可以参考下面的“定义jd_pet是否静默运行”部分，设定几个if判断条件
FRUIT_NOTIFY_CONTROL=""


################################## 定义jd_fruit是否使用水滴换豆卡（选填） ##################################
## 如果出现限时活动时100g水换20豆，此时比浇水划算，"true" 表示换豆（不浇水），"false" 表示不换豆（继续浇水）,默认是"false"
## 如需切换为换豆（不浇水），请修改为 "true"
FRUIT_BEAN_CARD="false"


################################## 定义jd_joy喂食克数（选填） ##################################
## 你期望的jd_joy每次喂食克数，只能填入10、20、40、80，默认为10
## 如实际持有食物量小于所设置的克数，脚本会自动降一档，直到降无可降
## 具体情况请自行在jd_joy游戏中去查阅攻略
JOY_FEED_COUNT=""


################################## 定义jd_joy兑换京豆数量（选填） ##################################
## 目前的可用值包括：0、20、500、1000，其中0表示为不自动兑换京豆，如不设置，将默认为"20"
## 不同等级可兑换不同数量的京豆，详情请见jd_joy游戏中兑换京豆选项
## 500、1000的京豆每天有总量限制，设置了并且你也有足够积分时，也并不代表就一定能抢到
JD_JOY_REWARD_NAME="20"


################################## 定义jd_joy兑换京豆是否静默运行（选填） ##################################
## 默认为 "false"，在成功兑换京豆时将发送推送通知消息（失败不发送），如想要静默不发送通知，请修改为 "true"
JD_JOY_REWARD_NOTIFY="false"


################################## 定义jd_joy是否自动给好友的汪汪喂食（选填） ##################################
## 默认 "false" 不会自动给好友的汪汪喂食，如想自动喂食，请改成 "true"
JOY_HELP_FEED="true"


################################## 定义jd_joy是否自动报名宠物赛跑（选填） ##################################
## 默认 "true" 参加宠物赛跑，如需关闭，请改成 "false"
JOY_RUN_FLAG=""


################################## 定义jd_joy参加比赛类型（选填） ##################################
## 当JOY_RUN_FLAG不设置或设置为 "true" 时生效
## 可选值：2,10,50，其他值不可以。其中2代表参加双人PK赛，10代表参加10人突围赛，50代表参加50人挑战赛，不填时默认为2
## 各个账号间请使用 & 分隔，比如：JOY_TEAM_LEVEL="2&2&50&10"
## 如果你有5个账号但只写了四个数字，那么第5个账号将默认参加2人赛，账号如果更多，与此类似
JOY_TEAM_LEVEL="10"


################################## 定义jd_joy赛跑自己账号内部是否开启互助（选填） ##################################
## 输入 true 为开启内部互助
JOY_RUN_HELP_MYSELF="true"


################################## 定义jd_joy赛跑获胜后是否推送通知（选填） ##################################
## 控制jd_joy.js脚本jd_joy赛跑获胜后是否推送通知，"false" 为否(不推送通知消息)，"true" 为是(即：发送推送通知消息)，默认为 "true"
JOY_RUN_NOTIFY="true"


################################## 定义jd_moneyTree是否自动将金果卖出变成金币（选填） ##################################
## 金币有时效，默认为 "false"，不卖出金果为金币，如想希望自动卖出，请修改为 "true"
MONEY_TREE_SELL_FRUIT="true"


################################## 定义jd_pet是否静默运行（选填） ##################################
## 默认 "false"（不静默，发送推送通知消息），如想静默请修改为 true
## 每次执行脚本通知太频繁了，改成只在周三和周六中午那一次运行时发送通知提醒
## 除掉上述提及时间之外，均设置为 true，静默不发通知
## 特别说明：针对北京时间有效。
if [ $(date "+%-w") -eq 6 ] && [ $(date "+%-H") -ge 9 ] && [ $(date "+%-H") -lt 14 ]; then
         PET_NOTIFY_CONTROL="false"
elif [ $(date "+%-w") -eq 3 ] && [ $(date "+%-H") -ge 9 ] && [ $(date "+%-H") -lt 14 ]; then
         PET_NOTIFY_CONTROL="false"
else
         PET_NOTIFY_CONTROL="true"
fi


################################## 定义jd_dreamFactory控制哪个JD账号不运行此脚本（选填） ##################################
## 输入"1"代表第一个JD账号不运行，多个使用 & 连接，例："1&3" 代表账号1和账号3不运行jd_dreamFactory脚本，注：输入"0"，代表全部账号不运行jd_dreamFactory脚本
## 如果使用了 “临时屏蔽某个Cookie” TempBlockCookie 功能，编号会发生变化
DREAMFACTORY_FORBID_ACCOUNT=""


################################## 定义jd_jdfactory控制哪个JD账号不运行此脚本（选填） ##################################
## 输入"1"代表第一个JD账号不运行，多个使用 & 连接，例："1&3" 代表账号1和账号3不运行jd_jdfactory脚本，注：输入"0"，代表全部账号不运行jd_jdfactory脚本
## 如果使用了 “临时屏蔽某个Cookie” TempBlockCookie 功能，编号会发生变化
JDFACTORY_FORBID_ACCOUNT=""


################################## 定义jd_jdfactory心仪的商品（选填） ##################################
## 只有在满足以下条件时，才自动投入电力：一是存储的电力满足生产商品所需的电力，二是心仪的商品有库存，如果没有输入心仪的商品，那么当前你正在生产的商品视作心仪的商品
## 如果你看不懂上面的话，请去jd_jdfactory游戏中查阅攻略
## 心仪的商品请输入商品的全称或能唯一识别出该商品的关键字
FACTORAY_WANTPRODUCT_NAME=""


################################## 定义jd_jxnc通知级别（选填） ##################################
## 可用值： 0(不通知); 1(本次获得水滴>0); 2(任务执行); 3(任务执行+未种植种子)，默认为"3"
JXNC_NOTIFY_LEVEL="3"


################################## 定义jd_cfd通知开关（选填） ##################################
## 输入 true 为通知，不填则为不通知
CFD_NOTIFY_CONTROL=""


################################## 定义jd_jxd是否自动把抽奖卷兑换为兑币 ##################################
## 输入 true 为自动兑换，不填则为不兑换
JD_JXD_EXCHANGE=""


################################## 定义jd_necklace是否是否静默运行 ##################################
## 控制点点券是否静默运行，false 为否(默认值false，发送推送通知消息)，true 为是(即：不发送推送通知消息)
DDQ_NOTIFY_CONTROL=""


################################## 定义jd_cash是否是否静默运行 ##################################
## 控制签到领现金是否静默运行，false 为否(默认值false，发送推送通知消息)，true 为是(即：不发送推送通知消息)
CASH_NOTIFY_CONTROL="false"


################################## 定义jd_jdzz是否是否静默运行 ##################################
## 控制京东赚赚是否静默运行，false 为否(默认值false，发送推送通知消息)，默认每月1日推送一次通知，true 为是(即：不发送推送通知消息)，
JDZZ_NOTIFY_CONTROL="false"

## ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 第四区域：本shell脚本特有变量填写区域 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓

## 临时屏蔽某个Cookie（选填）
## 如果某些Cookie已经失效了，但暂时还没法更新，可以使用此功能在不删除该Cookie和重新修改Cookie编号的前提下，临时屏蔽掉某些编号的Cookie
## 多个Cookie编号以半角的空格分隔，两侧一对半角双引号，使用此功能后，在运行js脚本时账号编号将发生变化
## 举例1：TempBlockCookie="2"    临时屏蔽掉Cookie2
## 举例2：TempBlockCookie="2 4"  临时屏蔽掉Cookie2和Cookie4
## 如果只是想要屏蔽某个账号不玩某些小游戏，可以参考下面 case 这个命令的例子来控制，脚本名称请去掉后缀 “.js”
## case $1 in
##   jd_fruit)
##     TempBlockCookie="5"      # 账号5不玩jd_fruit
##     ;;
##   jd_dreamFactory | jd_jdfactory)
##     TempBlockCookie="2"      # 账号2不玩jd_dreamFactory和jd_jdfactory
##     ;;
##   jd_jdzz | jd_joy)
##     TempBlockCookie="3 6"    # 账号3、账号6不玩jd_jdzz和jd_joy
##     ;;
##  esac
TempBlockCookie=""

## 是否自动删除 jd_scripts 项目中失效的脚本与定时任务（选填）
## 有的时候，某些JS脚本只在特定的时间有效，过了时间就失效了，需要自动删除失效的本地定时任务，则设置为 "true" ，否则请设置为 "false"
## 检测文件：lxk0301/jd_scripts 仓库中的 docker/crontab_list.sh
## 当设置为 "true" 时，会自动从检测文件中读取比对删除的任务（识别以“jd_”、“jr_”、“jx_”开头的任务）
## 当设置为 "true" 时，脚本只会删除一整行失效的定时任务，不会修改其他现有任务，所以任何时候，你都可以自己调整你的crontab.list
## 当设置为 "true" 时，如果你有添加额外脚本是以“jd_”“jr_”“jx_”开头的，如检测文件中，会被删除，不是以“jd_”“jr_”“jx_”开头的任务则不受影响
AutoDelCron="true"

## 是否自动增加 jd_scripts 项目中新的本地定时任务（选填）
## lxk0301 大佬会在有需要的时候，增加定时任务，如需要本地自动增加新的定时任务，则设置为 "true" ，否则请设置为 "false"
## 检测文件：lxk0301/jd_scripts 仓库中的 docker/crontab_list.sh
## 当设置为 "true" 时，如果检测到检测文件中有增加新的定时任务，那么在本地也增加（识别以“jd_”、“jr_”、“jx_”开头的任务）
## 当设置为 "true" 时，会自动从检测文件新增加的任务中读取时间，该时间为北京时间
## 当设置为 "true" 时，脚本只会增加新的定时任务，不会修改其他现有任务，所以任何时候，你都可以自己调整你的crontab.list
AutoAddCron="true"

## 删除日志的时间（选填） 
## 在运行删除旧的日志任务时，要删除多少天以前的日志，请输入正整数，不填则禁用删除日志的功能
RmLogDaysAgo="1"

## 随机延迟启动任务（选填）
## 如果任务不是必须准点运行的任务，那么给它增加一个随机延迟，由你定义最大延迟时间，单位为秒，如 RandomDelay="300" ，表示任务将在 1-300 秒内随机延迟一个秒数，然后再运行
## 在crontab.list中，在每小时第0-2分、第30-31分、第59分这几个时间内启动的任务，均算作必须准点运行的任务，在启动这些任务时，即使你定义了RandomDelay，也将准点运行，不启用随机延迟
## 在crontab.list中，除掉每小时上述时间启动的任务外，其他任务在你定义了 RandomDelay 的情况下，一律启用随机延迟，但如果你按照Wiki教程给某些任务添加了 "now"，那么这些任务也将无视随机延迟直接启动
RandomDelay="5"

## 自动按顺序进行账号间互助（选填）
## 设置为 true 时，以下所有互助活动，账号间将按照config.sh中Cookie顺序进行互助，此时，不会助力不在config.sh中的账号，无法和别人交换助力
## MyXxxx系列变量仍然需要填写，但ForOtherXxxx系列变量不再需要填写（填写了也无效）
## 如果启用了TempBlockCookie，那么只是被屏蔽的账号不助力其他账号，其他账号还是会助力被屏蔽的账号
AutoHelpOther=""

## 导出互助码模板样式（选填），定义 jcode 脚本导出的互助码模板样式。
## 不填 使用“按编号顺序助力模板”，Cookie编号在前的优先助力
## 填 0 使用“全部一致助力模板”，所有账户要助力的码全部一致，和启用 AutoHelpOther 的效果差不多
## 填 1 使用“均等机会助力模板”，所有账户获得助力次数一致
## 填 2 使用“随机顺序助力模板”，本套脚本内账号间随机顺序助力，每次生成的顺序都不一致。
HelpType="1"

## 是否添加DIY脚本（选填）
## 如果你自己会写shell脚本，并且希望在每次git_pull.sh这个脚本运行时，额外运行你的DIY脚本，请赋值为 "true"
## 同时，请务必将你的脚本命名为 diy.sh (只能叫这个文件名)，放在 config 目录下
## 我已定义好的变量，你如果想直接使用，可以参考本仓库下 git_pull.sh 文件
EnableExtraShell="true"

## 启用其他开发者的仓库方式一（选填）：完整更新整个仓库，针对同一个仓库，方式一和方式二只能选择一种
## OwnRepoUrl：仓库地址清单，必须从1开始依次编号
## OwnRepoBranch：你想使用的分支清单，不指定分支（即使用默认分支）时可以用一对不包含内容的空引号""，编号必须和 OwnRepoUrl 对应。
## OwnRepoPath：要使用的脚本在仓库哪个路径下，请输入仓库下的相对路径，默认空值""代表仓库根目录，编号必须和 OwnRepoUrl 对应。
## 所有脚本存放在 own 目录下，三个清单必须一一对应，示例如下：
## OwnRepoUrl1="https://gitee.com/abc/jdtsa.git"
## OwnRepoUrl2="https://github.com/nedcd/jxddfsa.git"
## OwnRepoUrl3="git@github.com:eject/poex.git"
## 
## OwnRepoBranch1=""         # 代表第1个仓库 https://gitee.com/abc/jdtsa.git 使用 "默认" 分支
## OwnRepoBranch2="main"     # 代表第2个仓库 https://github.com/nedcd/jxddfsa.git 使用 "main" 分支
## OwnRepoBranch3="master"   # 代表第3个仓库 git@github.com:eject/poex.git 使用 "master" 分支
## 
## OwnRepoPath1=""            # 代表第1个仓库https://gitee.com/abc/jdtsa.git，你想使用的脚本就在仓库根目录下。
## OwnRepoPath2="scripts/jd"  # 代表第2个仓库https://github.com/nedcd/jxddfsa.git，你想使用的脚本在仓库的 scripts/jd 文件夹下，必须输入相对路径
## OwnRepoPath3="task"        # 代表第3个仓库git@github.com:eject/poex.git，你想使用的脚本在仓库的 task 文件夹下，必须输入相对路径

OwnRepoUrl1=""
OwnRepoUrl2=""

OwnRepoBranch1=""
OwnRepoBranch2=""

OwnRepoPath1=""
OwnRepoPath2=""

## 启用其他开发者的仓库方式二（选填）：只下载想要的文件，针对同一个仓库，方式一和方式二只能选择一种。
## 请先确认你能正常下载该raw文件才列在下方，无论是github还是gitee，请只填入 raw 文件链接。
## 一行一个文件下载链接，首尾一对半角括号，示例：
## OwnRawFile=(
##     https://gitee.com/wabdwdd/scipts/raw/master/jd_abc.js
##     https://github.com/lonfeg/loon/raw/main/jd_dudi.js
##     https://github.com/sunsem/qx/raw/main/z_dida.js
## )
OwnRawFile=(

)

## 是否自动增加 own 类脚本（其他开发者脚本）的cron任务（选填）
## 本shell脚本不一定能完全从js脚本中识别出有效的cron设置，如果发现不能满足你的需要，请设置为 "false" 以取消自动增加。
AutoAddOwnCron="true"

## 是否自动删除 own 类脚本（其他开发者脚本）的cron任务（选填）
## 本shell脚本不一定能完全从js脚本中识别出有效的cron设置，如果发现不能满足你的需要，请设置为 "false" 以取消自动删除。
AutoDelOwnCron="true"

## ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑ 第四区域：本shell脚本特有变量填写区域 ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑



## ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 第五区域：额外的环境变量填写区域 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
## 请在以下补充你需要用到的额外的环境变量，形式：export 变量名="变量值"，或：export 变量名='变量值'


## ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑ 第五区域：额外的环境变量填写区域 ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑
